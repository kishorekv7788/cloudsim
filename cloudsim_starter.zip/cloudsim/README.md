# CloudSim - Multi-Cloud Simulation Platform (starter)

Companion code for the "Multi-Cloud Simulation Platform - Developer & QA Blueprint" PDF.

## Layout
- backend/app/engine   simulation engine (pure Python + PyYAML)
- backend/app/main.py  FastAPI API
- backend/app/db       PostgreSQL schema
- backend/tests        pytest tests (stage1, stage2, stage3, final)
- labs/                lab definitions (JSON)
- content/             theory lessons and quizzes (JSON)
- frontend/            React + Vite + Konva canvas, PWA files

## Run
    python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
    pip install -r backend/requirements.txt
    cd backend && pytest                                    # engine tests
    uvicorn app.main:app --reload                           # API docs at http://127.0.0.1:8000/docs
    cd ../frontend && npm install && npm run dev            # UI at http://localhost:5173

## Status
- Engine + tests: executed and passing.
- FastAPI layer: wiring checked, not run under a real server yet.
- SQL, React canvas, service worker, Pyodide loader: starters - run and adjust them.
