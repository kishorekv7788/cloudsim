import React from "react";
import { createRoot } from "react-dom/client";
import Canvas from "./Canvas.jsx";
import { registerServiceWorker } from "./registerSW.js";

createRoot(document.getElementById("root")).render(<Canvas labId="az900-lab02" />);
registerServiceWorker();
